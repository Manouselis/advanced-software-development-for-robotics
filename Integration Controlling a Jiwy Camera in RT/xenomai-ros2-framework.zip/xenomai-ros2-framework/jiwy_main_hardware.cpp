#include <stdio.h>
#include <unistd.h>
#include <iterator>
#include <signal.h>
#include <vector>
#include <sys/syscall.h>
#include <math.h>
#include <iostream>

#include "framework/multiCommClass.h"
#include "framework/runnableClass.h"
#include "framework/superThread.h"
#include "framework/icoCommClass.h"
// #include <Your 20-sim-code-generated h-file?> Don't forget to compile the cpp file by adding it to CMakeLists.txt
#include "ControllerPan/ControllerPan.h"
#include "ControllerTilt/ControllerTilt.h"

volatile bool exitbool = false;

void exit_handler(int s)
{
    printf("Caught signal %d\n", s);
    exitbool = true;
}

void ReadConvert_tilt(const double *src, double *dst)
{
    double max_count = 16383.0;
    double revolution_angle = 2 * M_PI; // Check in lab what is the the revolution angle of the camera (ask TA)
    double rad_per_count = revolution_angle / 2000;
    static double current_angle = 0.0;
    static double last_count = 0.0;
    double current_count = src[0];
    double real_current_count = 0.0;

    // Check for over/under wraping
    // 300 here is a chosen value to detect a sudden jump in the encoder count which is a sign of over/under wraping
    // The maximum jump in the encoder count is 16383 which is the maximum value of the encoder count register (14 bits)
    if (current_count - last_count > 300){
        real_current_count = -1 - ((int)current_count % (int)max_count);
    }else if (current_count - last_count < -300){
        real_current_count = max_count + ((int)current_count % (int)max_count) + 1;
    }else{
        real_current_count = current_count;
    }

    current_angle += (real_current_count - last_count) * rad_per_count;
    last_count = current_count;

    dst[0] = current_angle;
}

void WriteConvert_tilt(const double *src, double *dst)
{
    //double input_min = -1.0;
    //double input_max = 1.0;
    //int output_min = -2047;
    //int output_max = 2047;
    //dst[0] = (int)((src[0] - input_min) / (input_max - input_min) * (output_max - output_min) + output_min);
	dst[0] = (int)((src[0]/100)*2047.0); //Map from [-100, 100] to [-2047,2047]
}

void ReadConvert_pan(const double *src, double *dst)
{
    double max_count = 16383.0;
    double revolution_angle = 2 * M_PI; // Check in lab what is the the revolution angle of the camera (ask TA)
    double rad_per_count = revolution_angle / (4*1250);
    static double current_angle = 0.0;
    static double last_count = 0.0;
    double current_count = src[3];
    double real_current_count = 0.0;

    // Check for over/under wraping
    // 300 here is a chosen value to detect a sudden jump in the encoder count which is a sign of over/under wraping
    // The maximum jump in the encoder count is 16383 which is the maximum value of the encoder count register (14 bits)
    if (current_count - last_count > 300){
        real_current_count = -1 - ((int)current_count % (int)max_count);
    }else if (current_count - last_count < -300){
        real_current_count = max_count + ((int)current_count % (int)max_count) + 1;
    }else{
        real_current_count = current_count;
    }

    current_angle += (real_current_count - last_count) * rad_per_count;
    last_count = current_count;

    dst[3] = current_angle;
}

void WriteConvert_pan(const double *src, double *dst)
{
    //double input_min = -1.0;
    //double input_max = 1.0;
    //int output_min = -2047;
    //int output_max = 2047;
    //dst[2] = (int)((src[2] - input_min) / (input_max - input_min) * (output_max - output_min) + output_min);
	dst[2] = (int)((src[2]/100)*2047.0); //Map from [-100, 100] to [-2047,2047]
}

int main()
{
    //CREATE CNTRL-C HANDLER
    signal(SIGINT, exit_handler);

    printf("Press Ctrl-C to stop program\n"); // Note: this will 
        // not kill the program; just jump out of the wait loop. Hence,
        // you can still do proper clean-up. You are free to alter the
        // way of determining when to stop (e.g., run for a fixed time).


    // CONFIGURE, CREATE AND START THREADS HERE

    // CREATE PARAM AND WRAPPER FOR CONTROLLER

    // %%%%%%%%%%%%%%%%%%%%%%%%%% Question to TA, should it be icoComm instance for each controller or just one instance for both controllers? %%%%%%%%%%%%%%%%%%%%%%%%%%

    // Tilt 
	//u param
    int xddp_uparam_setpoint_tilt [] = {0};
	int xddp_uParam_feedback_tilt [] = {1};
	
	//y param
    int xddp_yparam_logging_tilt [] = {0};
    
	//IcoComm
	int _sendParam_tilt [] = {0, -1, -1, -1, -1, -1, -1, -1};// read from y[0] to SPI_OUTPUT[0]
    int _receiveParam_tilt [] = {1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};// write from SPI_INPUT[0] to u[1]
    IcoComm* icoComm_tilt = new IcoComm(_sendParam_tilt, _receiveParam_tilt);
    icoComm_tilt->setReadConvertFcn(&ReadConvert_tilt);
    icoComm_tilt->setWriteConvertFcn(&WriteConvert_tilt);
	// icoComm_tilt->setVerbose(true);
    
    frameworkComm *controller_tilt_uPorts [] = {
        // new IDDPComm(5, -1, 1, iddp_uParam_feedback_tilt), 
        new XDDPComm(10, -1, 1, xddp_uparam_setpoint_tilt),
        icoComm_tilt
    };
    frameworkComm *controller_tilt_yPorts [] = {
        new XDDPComm(26, 27, 1, xddp_yparam_logging_tilt),
        icoComm_tilt
    };
    ControllerTilt *controller_tilt = new ControllerTilt;
    runnable *controller_tilt_runnable = new wrapper<ControllerTilt>(controller_tilt,
                        controller_tilt_uPorts, controller_tilt_yPorts,
                        2, 1);
    controller_tilt_runnable->setSize(2,1);

    ////////////////////////////////////////////////////////////////////////////////////////////

    // Pan
    //u param
    //int xddp_uparam_setpoint_pan [] = {0};
	//int xddp_uParam_feedback_pan [] = {1};

	//y param
    //int xddp_yparam_logging_pan [] = {0};
	
	// IcoComm
    //int _sendParam_pan [] = {-1, -1, 0, -1, -1, -1, -1, -1}; //read from y[0] and write it to SPI_OUTPUT[2]
    //int _receiveParam_pan [] = {-1, -1, -1, 1, -1, -1, -1, -1, -1, -1, -1, -1}; //write to u[1] from SPI_INPUT[3]
    //IcoComm* icoComm_pan = new IcoComm(_sendParam_pan, _receiveParam_pan);
    //icoComm_pan->setReadConvertFcn(&ReadConvert_pan);
    //icoComm_pan->setWriteConvertFcn(&WriteConvert_pan);

    //frameworkComm *controller_pan_uPorts [] = {
        // new IDDPComm(3, -1, 1, iddp_uParam_feedback_pan), 
        //new XDDPComm(4, -1, 1, xddp_uparam_setpoint_pan),
        //icoComm_pan
  //  };
    //frameworkComm *controller_pan_yPorts [] = {
       // new XDDPComm(28, 28, 1, xddp_yparam_logging_pan),
       // icoComm_pan
   // };
   // ControllerPan *controller_pan = new ControllerPan;
   // runnable *controller_pan_runnable = new wrapper<ControllerPan>(controller_pan, 
                        //controller_pan_uPorts, controller_pan_yPorts, 
                        //2, 1);
   // controller_pan_runnable->setSize(2,1);
    ////////////////////////////////////////////////////////////////////////////////////////////

    // Thread management
    int controller_freq = 1000; // Hz
    int controller_period_ns = (1/controller_freq)*1000000000; // ns
   // xenoThread controller_pan_xeno(controller_pan_runnable);
    xenoThread controller_tilt_xeno(controller_tilt_runnable);
    controller_tilt_xeno.init(controller_period_ns, 99, 0); // period, priority, cpu affinity (? ask TA, most probably it is the core number)
   // controller_pan_xeno.init(controller_period_ns, 98, 1); // period, priority, cpu affinity (? ask TA, most probably it is the core number)
    //controller_tilt_xeno.enableLogging(true, 26); // enable logging to ros
    //controller_pan_xeno.enableLogging(true, 28); // enable logging to ros
    // Start threads
    //controller_pan_xeno.start("controller_pan");
    controller_tilt_xeno.start("controller_tilt");
    
    // WAIT FOR CNTRL-C
    timespec t = {.tv_sec=0, .tv_nsec=100000000}; // 1/10 second
    double spi_rec [] = {0, 1}; 
    // double spi_rec2[12]; 
    while (!exitbool)
    {
        icoComm_tilt->receive(spi_rec);
    //     int n = sizeof(spi_rec) / sizeof(spi_rec[0]);

    //      // Print the elements of spi_rec
    //      std::cout << "spi_rec: [";
    //     for (int i = 0; i < n; i++) {
    //         std::cout << spi_rec[i];
    //         if (i < n-1) {
    //             std::cout << ", ";
    //     }
    // }
    // std::cout << "]" << std::endl;
        // Let the threads do the real work
        nanosleep(&t, NULL);
        // Wait for Ctrl-C to exit
    }
    printf("Ctrl-C was pressed: Stopping gracefully...\n");

    //CLEANUP HERE
    //controller_pan_xeno.stopThread();
    controller_tilt_xeno.stopThread();
   // controller_pan_xeno.~xenoThread();
    controller_tilt_xeno.~xenoThread();
    //controller_pan_runnable->~runnable();
    controller_tilt_runnable->~runnable();

    return 0;
}