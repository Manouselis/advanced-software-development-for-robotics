#include <stdio.h>
#include <unistd.h>
#include <iterator>
#include <signal.h>
#include <vector>
#include <sys/syscall.h>
#include <math.h>

#include "framework/multiCommClass.h"
#include "framework/runnableClass.h"
#include "framework/superThread.h"
#include "framework/icoCommClass.h"
// #include <Your 20-sim-code-generated h-file?> Don't forget to compile the cpp file by adding it to CMakeLists.txt
#include "ControllerPan/ControllerPan.h"
#include "ControllerTilt/ControllerTilt.h"

volatile bool exitbool = false;

void exit_handler(int s)
{
    printf("Caught signal %d\n", s);
    exitbool = true;
}

void ReadConvert_tilt(const double *src, double *dst) //src has size 12 we only want src[0]
{
    double max_count = 16383.0;
    double revolution_angle = 2 * M_PI; // Check in lab what is the the revolution angle of the camera (ask TA)
    double rad_per_count = revolution_angle / 2000;
    static double current_angle = 0.0; //CHANGE HERE
    static double last_count = 0.0;
    double current_count = src[0];
    double real_current_count = 0.0;

    // Check for over/under wraping
    // 300 here is a chosen value to detect a sudden jump in the encoder count which is a sign of over/under wraping
    // The maximum jump in the encoder count is 16383 which is the maximum value of the encoder count register (14 bits)
    if (current_count - last_count > 300){
        real_current_count = -1 - ((int)current_count % (int)max_count);
    }else if (current_count - last_count < -300){
        real_current_count = max_count + ((int)current_count % (int)max_count) + 1; //CHANGE HERE
    }else{
        real_current_count = current_count;
    }

    current_angle += (real_current_count - last_count) * rad_per_count;
    last_count = current_count;

    dst[0] = current_angle;
}

void WriteConvert_tilt(const double *src, double *dst)
{
    double input_min = -1.0;
    double input_max = 1.0;
    int output_min = -2047;
    int output_max = 2047;
    //dst[0] = (int)((src[0] - input_min) / (input_max - input_min) * (output_max - output_min) + output_min);
	dst[0] = (int)((src[0]/100)*2047.0); //Map from [-100, 100] to [-2047,2047]
}


int main()
{
    //CREATE CNTRL-C HANDLER
    signal(SIGINT, exit_handler);

    printf("Press Ctrl-C to stop program\n"); // Note: this will 
        // not kill the program; just jump out of the wait loop. Hence,
        // you can still do proper clean-up. You are free to alter the
        // way of determining when to stop (e.g., run for a fixed time).


    // CONFIGURE, CREATE AND START THREADS HERE

    // CREATE PARAM AND WRAPPER FOR CONTROLLER

    // %%%%%%%%%%%%%%%%%%%%%%%%%% Question to TA, should it be icoComm instance for each controller or just one instance for both controllers? %%%%%%%%%%%%%%%%%%%%%%%%%%

    // Test communication for Tilt. It can be adjusted for the pan as well.
    // int iddp_uParam_feedback_tilt [] = {1};
    int xddp_uparam_from_ros [] = {0};
	int xddp_uparam_from_SPI [] = {1};
	int xddp_yparam_logging_to_SPI [] = {0};
    int xddp_yparam_logging_to_ros [] = {1};

    int _sendParam [] = {0, -1, -1, -1, -1, -1, -1, -1}; //y[0] will go through mywrite to the motors
    int _receiveParam [] = {1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1}; //u[1] will be written upon by my read()
    IcoComm *icoComm_tilt = new IcoComm(_sendParam, _receiveParam);
    icoComm_tilt->setReadConvertFcn(&ReadConvert_tilt);
    icoComm_tilt->setWriteConvertFcn(&WriteConvert_tilt);
    frameworkComm *test_comm_uPorts [] = {
        // new IDDPComm(5, -1, 1, iddp_uParam_feedback_tilt), 
        new XDDPComm(10, -1, 1, xddp_uparam_from_ros),//write to u[0] from ros
        icoComm_tilt //write to u[1] from SPI
    };
    frameworkComm *test_comm_yPorts [] = {
        new XDDPComm(28, 28, 1, xddp_yparam_logging_to_SPI),//y[0] to ros
        icoComm_tilt, //y[0] to SPI
		new XDDPComm(26, 26, 1, xddp_yparam_logging_to_ros)//y[1] to ros
    };
	//Since y[1] is equal to u[1] which is equal to the ouput of my read we get that
	//way the my read ouput
    TestComm *test_comm = new TestComm; // This simple 20-sim c++ code has to be generated. It should be designed such that it takes to inputs and outputs them to two outputs as they are (like multiplying by 1 for example).
    runnable *test_comm_runnable = new wrapper<TestComm>(test_comm,
                        test_comm_uPorts, test_comm_yPorts,
                        2, 2); //Change it here please

    ////////////////////////////////////////////////////////////////////////////////////////////

    // Thread management
    int test_comm_freq = 1000; // Hz
    int test_comm_period_ns = (1/test_comm_freq)*1000000000; // ns
    xenoThread test_comm_xeno(test_comm_runnable);
    test_comm_xeno.init(test_comm_period_ns, 99, 0); // period, priority, cpu affinity (? ask TA, most probably it is the core number)
    test_comm_xeno.enableLogging(true, 26); // enable logging to ros
    test_comm_xeno.enableLogging(true, 28); // enable logging to ros
    // Start threads
    test_comm_xeno.start("test_comm");
    
    // WAIT FOR CNTRL-C
    timespec t = {.tv_sec=0, .tv_nsec=100000000}; // 1/10 second

    while (!exitbool)
    {
        // Let the threads do the real work
        nanosleep(&t, NULL);
        // Wait for Ctrl-C to exit
    }
    printf("Ctrl-C was pressed: Stopping gracefully...\n");

    //CLEANUP HERE
    test_comm_xeno.stopThread();
    test_comm_xeno.~xenoThread();
    test_comm_runnable->~runnable();

    return 0;
}