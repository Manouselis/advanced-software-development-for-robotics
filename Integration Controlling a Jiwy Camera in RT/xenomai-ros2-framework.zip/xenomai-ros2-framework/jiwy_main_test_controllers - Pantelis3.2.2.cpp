#include <stdio.h>
#include <unistd.h>
#include <iterator>
#include <signal.h>
#include <vector>
#include <sys/syscall.h>
#include <math.h>

#include "framework/multiCommClass.h"
#include "framework/runnableClass.h"
#include "framework/superThread.h"
#include "framework/icoCommClass.h"
// #include <Your 20-sim-code-generated h-file?> Don't forget to compile the cpp file by adding it to CMakeLists.txt
#include "ControllerPan/ControllerPan.h"
#include "ControllerTilt/ControllerTilt.h"

volatile bool exitbool = false;

void exit_handler(int s)
{
    printf("Caught signal %d\n", s);
    exitbool = true;
}

int main()
{
    //CREATE CNTRL-C HANDLER
    signal(SIGINT, exit_handler);

    printf("Press Ctrl-C to stop program\n"); // Note: this will 
        // not kill the program; just jump out of the wait loop. Hence,
        // you can still do proper clean-up. You are free to alter the
        // way of determining when to stop (e.g., run for a fixed time).


    // CONFIGURE, CREATE AND START THREADS HERE

    // CREATE PARAM AND WRAPPER FOR CONTROLLER

    // Tilt
    // int iddp_uParam_feedback_tilt [] = {1};
    int xddp_uparam_setpoint_tilt [] = {0};
    int xddp_yparam_logging_tilt [] = {0};

    frameworkComm *controller_tilt_uPorts [] = {
        new XDDPComm(10, -1, 1, xddp_uparam_setpoint_tilt),
    };
    frameworkComm *controller_tilt_yPorts [] = {
        new XDDPComm(26, 26, 1, xddp_yparam_logging_tilt),
    };
    ControllerTilt *controller_tilt = new ControllerTilt;
    runnable *controller_tilt_runnable = new wrapper<ControllerTilt>(controller_tilt,
                        controller_tilt_uPorts, controller_tilt_yPorts,
                        1, 1);
    ////////////////////////////////////////////////////////////////////////////////////////////
    // Pan
    // int iddp_uParam_feedback_pan [] = {1};
    int xddp_uparam_setpoint_pan [] = {0};
    int xddp_yparam_logging_pan [] = {0};
    frameworkComm *controller_pan_uPorts [] = {
        new XDDPComm(4, -1, 1, xddp_uparam_setpoint_pan),
    };
    frameworkComm *controller_pan_yPorts [] = {
        new XDDPComm(28, 28, 1, xddp_yparam_logging_pan),
    };
    ControllerPan *controller_pan = new ControllerPan;
    runnable *controller_pan_runnable = new wrapper<ControllerPan>(controller_pan, 
                        controller_pan_uPorts, controller_pan_yPorts, 
                        1, 1);
    ////////////////////////////////////////////////////////////////////////////////////////////
    // Thread management
    int controller_freq = 1000; // Hz
    int controller_period_ns = (1/controller_freq)*1000000000; // ns
    xenoThread controller_pan_xeno(controller_pan_runnable);
    xenoThread controller_tilt_xeno(controller_tilt_runnable);
    controller_tilt_xeno.init(controller_period_ns, 99, 0); // period, priority, cpu affinity (? ask TA, most probably it is the core number)
    controller_pan_xeno.init(controller_period_ns, 98, 1); // period, priority, cpu affinity (? ask TA, most probably it is the core number)
    controller_tilt_xeno.enableLogging(true, 26); // enable logging to ros
    controller_pan_xeno.enableLogging(true, 28); // enable logging to ros
    // Start threads
    controller_pan_xeno.start("controller_pan");
    controller_tilt_xeno.start("controller_tilt");
    
    // WAIT FOR CNTRL-C
    timespec t = {.tv_sec=0, .tv_nsec=100000000}; // 1/10 second

    while (!exitbool)
    {
        // Let the threads do the real work
        nanosleep(&t, NULL);
        // Wait for Ctrl-C to exit
    }
    printf("Ctrl-C was pressed: Stopping gracefully...\n");

    //CLEANUP HERE
    controller_pan_xeno.stopThread();
    controller_tilt_xeno.stopThread();
    controller_pan_runnable->~xenoThread();
    controller_tilt_runnable->~xenoThread();
    controller_pan_runnable->~runnable();
    controller_tilt_runnable->~runnable();

    return 0;
}