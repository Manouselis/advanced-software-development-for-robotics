#include <cstdio>
#include <memory>
#include <vector>
#include <chrono>
#include <functional>

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"
#include "std_msgs/msg/bool.hpp"
#include "std_msgs/msg/float32.hpp"
#include "sensor_msgs/msg/image.hpp"
#include "sensor_msgs/image_encodings.hpp"
#include "asdfr_interfaces/msg/point2.hpp" // 2D point (x and y coordinates)

#include "image_functions.h"

using std::placeholders::_1;

using namespace std::chrono_literals;


class LightPos : public rclcpp::Node
{
  public:
    LightPos() : 
      Node("light_pos") 
    {
      // Listen to image topic /image
      RCLCPP_INFO(this->get_logger(), "listening for images at /image. Try:");
      RCLCPP_INFO(this->get_logger(), "  ros2 run image_tools cam2image");      
      subscriptionImage_ = this->create_subscription<sensor_msgs::msg::Image>(
        "image", 10, std::bind(&LightPos::topic_callback_image, this, _1));

      // Create a thresholded topic
      RCLCPP_INFO(this->get_logger(), "Creating /image_thresholded topic. Try:");
      RCLCPP_INFO(this->get_logger(), "  ros2 run image_tools showimage /image:=/image_thresholded");
      image_thresholded_topic_ = this->create_publisher<sensor_msgs::msg::Image>("image_thresholded",1);

      // Cog-pos
      RCLCPP_INFO(this->get_logger(), "Creating /light_cog. Try:");
      RCLCPP_INFO(this->get_logger(), "  ros2 topic echo /light_cog");
      light_cog_topic_ = this->create_publisher<asdfr_interfaces::msg::Point2>("light_cog",1);

      timer_ = this->create_wall_timer(33ms, std::bind(&LightPos::timer_callback, this));


      // Create a brightness_threshold parameter (initialized to 240)
      RCLCPP_INFO(this->get_logger(), "Creating binarizing_threshold parameter. Try:");
      RCLCPP_INFO(this->get_logger(), "  ros2 param set /light_pos binarizing_threshold 200");
      this->declare_parameter<int>("binarizing_threshold", 240);

      thr_image = sensor_msgs::msg::Image::SharedPtr(new sensor_msgs::msg::Image());
      cog_N = 0;
      cog_x = 0;
      cog_y = 0;
    }

  private:
    rclcpp::Subscription<sensor_msgs::msg::Image>::SharedPtr subscriptionImage_;
    rclcpp::Publisher<asdfr_interfaces::msg::Point2>::SharedPtr light_cog_topic_;
    rclcpp::Publisher<sensor_msgs::msg::Image>::SharedPtr image_thresholded_topic_;
    rclcpp::TimerBase::SharedPtr timer_;
    sensor_msgs::msg::Image::SharedPtr thr_image;
    int cog_N;
    int cog_x;
    int cog_y;

    void topic_callback_image(const sensor_msgs::msg::Image::SharedPtr img)
    {
      RCLCPP_INFO_ONCE(this->get_logger(), "Received first image!");
      RCLCPP_INFO_ONCE(this->get_logger(), "   Encoding = %s", img->encoding.c_str());
      RCLCPP_INFO_ONCE(this->get_logger(), "   W x H = %d x %d", img->width, img->height);
      // RCLCPP_INFO(this->get_logger(), "step = %d", img->step);
      // RCLCPP_INFO(this->get_logger(), "bigEndian = %d", img->is_bigendian);
      // RCLCPP_INFO(this->get_logger(), "frame-id = %s", img->header.frame_id.c_str());

      int brightness_threshold = 0; // No real need to intialize because it is set below, but this saves an "uninitialized" warning
      int binarizing_threshold = 0;
      this->get_parameter("brightness_threshold", brightness_threshold);
      this->get_parameter("binarizing_threshold", binarizing_threshold);

      // Create a thresholded image; both as an intermediate step as a 'debug' output.
      // On the same run, compute the center of gravity.
      thr_image = sensor_msgs::msg::Image::SharedPtr(new sensor_msgs::msg::Image());
      copyImageProperties(thr_image, img);
      int brightness, thresholdColor = 255;
        // Computation of COG = 1/N * sum(x_n) (where n=1..N; x_n is the x position of the n'th pixel that is above the threshold)
      double cog_sum_x = 0, cog_sum_y = 0; // In these variables we store  sum(x_n) and sum(y_n)
      cog_N = 0;                           // Number of pixels above the threshold
      for (int y = 0; y < getImageHeight(img); y++){ // Loop over rows
        for (int x = 0; x < getImageWidth(img); x++){ // Loop over columns
          brightness = getPixelBrightness(img, x, y);
          if (brightness >= binarizing_threshold){
            setPixelColor(thr_image, x, y, thresholdColor, thresholdColor, thresholdColor);
            cog_sum_x += x;
            cog_sum_y += y;
            cog_N++;
          } else
            setPixelColor(thr_image, x, y, 0, 0, 0);
        }
      }
    
      // Identify COG (if any). Put it in the image as a 3x3 square of dots
      // (unless it is too close to the edge)
      cog_x = 0, cog_y = 0;
      if (cog_N != 0)
      {
        cog_x = int(round(cog_sum_x / cog_N));
        cog_y = int(round(cog_sum_y / cog_N));
        DrawBigPixel(thr_image, cog_x, cog_y, 255, 0, 0, 5);
      }
      
    }

    void timer_callback() // Publisher call_back function
    {
      asdfr_interfaces::msg::Point2 cog_msg;
      cog_msg.x = cog_x;
      cog_msg.y = cog_y;
      light_cog_topic_->publish(cog_msg);

      // For debugging purposes
      image_thresholded_topic_->publish(*thr_image);

    }

};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<LightPos>());
  rclcpp::shutdown();
  return 0;
}
