Steps to compile and run 

1. Unzip in an empty directory <jiwy_ws>
2. Go to <jiwy_ws>
3. colcon build
4. In new terminal:
cd <jiwy_ws>
install/local_setup.sh
ros2 launch assignment3_ros assignment3_ros_launch.xml